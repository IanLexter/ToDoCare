package com.example.todocare;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import androidx.room.Delete;

import java.util.List;

@Dao
public interface AlarmDao {
    @Insert
    long insert(Alarm alarm);

    @Query("SELECT * FROM alarms")
    List<Alarm> getAllAlarms();

    @Delete // Use the Delete annotation to handle the deletion
    void delete(Alarm alarm); // Directly delete the Alarm object

    @Update
    void update(Alarm alarm); // Ensure you have the update method
}
