package com.example.todocare;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "alarms")
public class Alarm {
    @PrimaryKey(autoGenerate = true)
    public long id;

    public int hour;
    public int minute;
    public long timeInMillis;
}

