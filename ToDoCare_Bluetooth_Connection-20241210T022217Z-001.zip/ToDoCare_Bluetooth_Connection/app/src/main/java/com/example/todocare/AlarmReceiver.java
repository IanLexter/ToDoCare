package com.example.todocare;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.io.IOException;
import java.io.OutputStream;

public class AlarmReceiver extends BroadcastReceiver {
    private static final String TAG = "AlarmReceiver";
    private static final String CHANNEL_ID = "alarm_channel";
    private static final int NOTIFICATION_ID = 1;

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "Alarm received!");

        // Play alarm sound
        playAlarmSound(context);

        // Show notification
        showNotification(context);

        // Send Bluetooth command
        sendBluetoothCommand();
    }

    private void playAlarmSound(Context context) {
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmSound == null) {
            alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }

        MediaPlayer mediaPlayer = MediaPlayer.create(context, alarmSound);
        if (mediaPlayer != null) {
            mediaPlayer.setOnCompletionListener(mp -> {
                mp.release();
                Log.d(TAG, "Alarm sound stopped.");
            });

            try {
                mediaPlayer.start();
                Log.d(TAG, "Alarm sound started.");
            } catch (Exception e) {
                Log.e(TAG, "Error playing alarm sound", e);
                mediaPlayer.release();
            }
        } else {
            Log.e(TAG, "MediaPlayer failed to initialize.");
        }
    }

    private void sendBluetoothCommand() {
        Log.d(TAG, "Attempting to send Bluetooth command.");

        BluetoothSocket bluetoothSocket = MainActivity.getBluetoothSocket();
        OutputStream outputStream = MainActivity.getOutputStream();

        // Check if Bluetooth socket is set and connected
        if (bluetoothSocket == null || !bluetoothSocket.isConnected()) {
            Log.e(TAG, "Bluetooth socket is null or not connected.");
            return;
        }

        try {
            if (outputStream != null) {
                Log.d(TAG, "Sending Bluetooth command to HC-05");

                // Send 'A' command to the HC-05
                outputStream.write('A');

                Log.d(TAG, "Bluetooth command sent: 'A'");
            } else {
                Log.e(TAG, "Bluetooth output stream is null");
            }
        } catch (IOException e) {
            Log.e(TAG, "Error sending Bluetooth command", e);
        }
    }

    private void showNotification(Context context) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Create notification channel for Android 8.0 and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Alarm Notifications", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        // Create an intent to open the app when the notification is tapped
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_alarm)
                .setContentTitle("Alarm")
                .setContentText("Time to drink your medicine!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);

        // Show the notification
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }
}