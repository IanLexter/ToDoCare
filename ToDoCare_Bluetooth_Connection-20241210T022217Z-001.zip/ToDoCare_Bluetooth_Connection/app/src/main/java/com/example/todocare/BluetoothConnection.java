package com.example.todocare;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

public class BluetoothConnection {
    private static final String TAG = "BluetoothConnection";
    private static final String DEVICE_ADDRESS = "00:00:00:00:00:00"; // Replace with your device's MAC address
    private static final UUID UUID_DEVICE = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); // Standard SerialPortService ID

    private final BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket bluetoothSocket;
    private OutputStream outputStream;

    public BluetoothConnection() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    }

    @SuppressLint("MissingPermission")
    public boolean connect() {
        if (bluetoothAdapter == null) {
            Log.e(TAG, "Bluetooth is not supported.");
            return false;
        }

        try {
            BluetoothDevice device = bluetoothAdapter.getRemoteDevice(DEVICE_ADDRESS);
            bluetoothSocket = device.createRfcommSocketToServiceRecord(UUID_DEVICE);
            bluetoothSocket.connect();
            outputStream = bluetoothSocket.getOutputStream();
            Log.d(TAG, "Bluetooth connected");
            return true;
        } catch (IOException e) {
            Log.e(TAG, "Failed to connect to Bluetooth device", e);
            return false;
        }
    }

    public void sendCommand(char command) throws IOException {
        if (outputStream != null) {
            outputStream.write(command);
            Log.d(TAG, "Command sent: " + command);
        } else {
            Log.e(TAG, "Output stream is null. Not connected.");
        }
    }

    public void disconnect() {
        try {
            if (bluetoothSocket != null) {
                bluetoothSocket.close();
                Log.d(TAG, "Bluetooth disconnected");
            }
        } catch (IOException e) {
            Log.e(TAG, "Failed to disconnect Bluetooth", e);
        }
    }

    public boolean isConnected() {
        return bluetoothSocket != null && bluetoothSocket.isConnected();
    }
}
