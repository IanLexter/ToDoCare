package com.example.todocare;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import androidx.room.Room;

import java.util.Calendar;
import java.util.List;

public class AlarmManagerHelper {

    private Context context;
    private AlarmDatabase db;
    private AlarmAdapter alarmAdapter;
    private int alarmCount = 0;

    public AlarmManagerHelper(Context context) {
        this.context = context;
        db = Room.databaseBuilder(context.getApplicationContext(), AlarmDatabase.class, "alarm-database").allowMainThreadQueries().build();
        loadAlarms();
    }

    public void setAlarm(int hour, int minute) {
        if (alarmCount >= 4) {
            Toast.makeText(context, "You can only set up to 4 alarms", Toast.LENGTH_SHORT).show();
            return;
        }

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);

        long timeInMillis = calendar.getTimeInMillis();
        Alarm alarm = new Alarm();
        alarm.hour = hour;
        alarm.minute = minute;
        alarm.timeInMillis = timeInMillis;

        db.alarmDao().insert(alarm);
        alarmCount++;

        setAlarm(timeInMillis, alarmCount);
        Toast.makeText(context, "Alarm set for " + hour + ":" + String.format("%02d", minute), Toast.LENGTH_SHORT).show();
        loadAlarms();
    }

    @SuppressLint("ScheduleExactAlarm")
    private void setAlarm(long timeInMillis, int requestCode) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
    }

    public void deleteAlarm(Alarm alarm) {
        db.alarmDao().delete(alarm);
        alarmCount--;
        loadAlarms();
    }

    public void updateAlarm(Alarm alarm, int hour, int minute) {
        alarm.hour = hour;
        alarm.minute = minute;
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        alarm.timeInMillis = calendar.getTimeInMillis();

        db.alarmDao().update(alarm);
        loadAlarms();
    }

    private void loadAlarms() {
        List<Alarm> alarms = db.alarmDao().getAllAlarms();
        alarmAdapter = new AlarmAdapter(alarms, new AlarmAdapter.OnItemClickListener() {
            @Override
            public void onEditClick(Alarm alarm) {
                // Provide implementation to handle edit
            }

            @Override
            public void onDeleteClick(Alarm alarm) {
                deleteAlarm(alarm);
            }
        });
        // Assuming you have a method to set the adapter to the RecyclerView
        // recyclerView.setAdapter(alarmAdapter);
    }
}
