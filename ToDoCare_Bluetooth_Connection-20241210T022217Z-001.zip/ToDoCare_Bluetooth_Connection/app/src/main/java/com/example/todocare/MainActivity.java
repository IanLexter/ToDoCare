    package com.example.todocare;

    import android.Manifest;
    import android.annotation.SuppressLint;
    import android.app.AlarmManager;
    import android.app.Notification;
    import android.app.NotificationChannel;
    import android.app.NotificationManager;
    import android.app.PendingIntent;
    import android.app.TimePickerDialog;
    import android.bluetooth.BluetoothAdapter;
    import android.bluetooth.BluetoothDevice;
    import android.bluetooth.BluetoothSocket;
    import android.content.BroadcastReceiver;
    import android.content.Context;
    import android.content.Intent;
    import android.content.IntentFilter;
    import android.content.pm.PackageManager;
    import android.os.Build;
    import android.os.Bundle;
    import android.util.Log;
    import android.widget.Button;
    import android.widget.ImageButton;
    import android.widget.ImageView;
    import android.widget.TimePicker;
    import android.widget.Toast;

    import androidx.annotation.NonNull;
    import androidx.appcompat.app.AppCompatActivity;
    import androidx.core.app.ActivityCompat;
    import androidx.core.content.ContextCompat;
    import androidx.recyclerview.widget.LinearLayoutManager;
    import androidx.recyclerview.widget.RecyclerView;
    import androidx.room.Room;

    import java.io.IOException;
    import java.io.OutputStream;
    import java.util.Calendar;
    import java.util.List;
    import java.util.Set;
    import java.util.UUID;

    public class MainActivity extends AppCompatActivity {
        private static final int PERMISSION_REQUEST_RECORD_AUDIO = 1;
        private static final int REQUEST_NOTIFICATION_PERMISSION = 3;
        private static final String CHANNEL_ID = "alarm_channel";
        private static final String TAG = "MainActivity";
        private static final int REQUEST_ENABLE_BT = 1;
        private static final int REQUEST_PERMISSION_BLUETOOTH = 2;
        private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
        private static final String HC_05_NAME = "HC-05";

        private static BluetoothSocket bluetoothSocket;
        private static OutputStream outputStream;
        private BluetoothAdapter bluetoothAdapter;
        private BluetoothDevice hc05Device;

        TimePicker timePicker;
        Button btnSetAlarm;
        RecyclerView recyclerView;
        AlarmAdapter alarmAdapter;
        AlarmDatabase db;
        int alarmCount = 0;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            createNotificationChannel();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATION_PERMISSION);
                }
            }

            timePicker = findViewById(R.id.timePicker);
            btnSetAlarm = findViewById(R.id.btnSetAlarm);
            recyclerView = findViewById(R.id.recyclerView);
            ImageView ivMail = findViewById(R.id.ivMail);

            ivMail.setOnClickListener(v -> {
                Intent mailIntent = new Intent(MainActivity.this, MailActivity.class);
                startActivity(mailIntent);
            });

            db = Room.databaseBuilder(getApplicationContext(), AlarmDatabase.class, "alarm-database")
                    .build();

            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            loadAlarms();

            btnSetAlarm.setOnClickListener(v -> setAlarm());

            bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
            if (bluetoothAdapter == null) {
                Toast.makeText(this, "Bluetooth is not supported on this device", Toast.LENGTH_LONG).show();
                return;
            }

            ImageButton bluetoothButton = findViewById(R.id.button);
            bluetoothButton.setOnClickListener(v -> connectBluetooth());

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST_RECORD_AUDIO);
            } else {
                startVoiceAssistantService();
            }
        }

        private void connectBluetooth() {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                        REQUEST_PERMISSION_BLUETOOTH);
                return;
            }

            if (!bluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            } else {
                connectToHC05();
            }
        }

        @SuppressLint("MissingPermission")
        private void connectToHC05() {
            Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
            for (BluetoothDevice device : pairedDevices) {
                if (device.getName().equals(HC_05_NAME)) {
                    hc05Device = device;
                    new Thread(this::createBluetoothConnection).start();
                    return;
                }
            }
            Toast.makeText(this, "HC-05 not found. Please pair the device.", Toast.LENGTH_SHORT).show();
        }

        @SuppressLint("MissingPermission")
        private void createBluetoothConnection() {
            try {
                bluetoothSocket = hc05Device.createRfcommSocketToServiceRecord(MY_UUID);
                bluetoothSocket.connect();
                outputStream = bluetoothSocket.getOutputStream();
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Connected to HC-05", Toast.LENGTH_SHORT).show());
            } catch (IOException e) {
                Log.e(TAG, "Could not connect to HC-05", e);
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Failed to connect to HC-05", Toast.LENGTH_SHORT).show());
            }
        }

        private void setAlarm() {
            if (alarmCount >= 4) {
                Toast.makeText(MainActivity.this, "You can only set up to 4 alarms", Toast.LENGTH_SHORT).show();
                return;
            }

            int hour = timePicker.getHour();
            int minute = timePicker.getMinute();
            Calendar calendar = Calendar.getInstance();
            Calendar now = Calendar.getInstance();

            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);

            if (calendar.before(now)) {
                calendar.add(Calendar.DAY_OF_MONTH, 1);
            }

            long alarmTimeInMillis = calendar.getTimeInMillis();

            Log.d(TAG, "Setting alarm for requestCode: " + alarmCount + " at time: " + alarmTimeInMillis);

            new Thread(() -> {
                try {
                    Alarm alarm = new Alarm();
                    alarm.hour = hour;
                    alarm.minute = minute;
                    alarm.timeInMillis = alarmTimeInMillis;
                    long alarmId = db.alarmDao().insert(alarm);

                    if (alarmId != -1) {
                        Log.d(TAG, "Alarm inserted with ID: " + alarmId);
                        runOnUiThread(() -> {
                            setAlarmManager(alarmTimeInMillis, (int) alarmId);
                            loadAlarms();
                            Toast.makeText(MainActivity.this, "Alarm set for " + String.format("%02d:%02d", hour, minute), Toast.LENGTH_SHORT).show();
                        });
                        alarmCount++;
                    } else {
                        Log.e(TAG, "Failed to insert alarm");
                        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Failed to set alarm", Toast.LENGTH_SHORT).show());
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error setting alarm", e);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error setting alarm", Toast.LENGTH_SHORT).show());
                }
            }).start();
        }

        private void createNotificationChannel() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Alarm Notifications", NotificationManager.IMPORTANCE_HIGH);
                channel.setDescription("Notifications for alarm events");
                channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                channel.enableLights(true);
                channel.enableVibration(true);

                NotificationManager notificationManager = getSystemService(NotificationManager.class);
                notificationManager.createNotificationChannel(channel);
            }
        }

        @SuppressLint("ScheduleExactAlarm")
        private void setAlarmManager(long timeInMillis, int requestCode) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, AlarmReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                AlarmManager.AlarmClockInfo alarmClockInfo = new AlarmManager.AlarmClockInfo(timeInMillis, pendingIntent);
                alarmManager.setAlarmClock(alarmClockInfo, pendingIntent);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
            } else {
                alarmManager.set(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
            }

            Log.d(TAG, "Alarm set for " + new java.util.Date(timeInMillis).toString() + " with request code: " + requestCode);
        }

        private void loadAlarms() {
            new Thread(() -> {
                try {
                    List<Alarm> alarms = db.alarmDao().getAllAlarms();
                    runOnUiThread(() -> {
                        alarmAdapter = new AlarmAdapter(alarms, new AlarmAdapter.OnItemClickListener() {
                            @Override
                            public void onEditClick(Alarm alarm) {
                                showEditDialog(alarm);
                            }

                            @Override
                            public void onDeleteClick(Alarm alarm) {
                                cancelAlarm(alarm);
                                new Thread(() -> {
                                    db.alarmDao().delete(alarm);
                                    runOnUiThread(() -> {
                                        alarmCount--;
                                        loadAlarms();
                                    });
                                }).start();
                            }
                        });
                        recyclerView.setAdapter(alarmAdapter);
                        alarmCount = alarms.size();
                    });
                } catch (Exception e) {
                    Log.e(TAG, "Error loading alarms", e);
                }
            }).start();
        }

        private void cancelAlarm(Alarm alarm) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, AlarmReceiver.class);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, (int) alarm.id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            alarmManager.cancel(pendingIntent);
            Toast.makeText(this, "Alarm cancelled", Toast.LENGTH_SHORT).show();
        }

        private void showEditDialog(Alarm alarm) {
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    this,
                    (view, hourOfDay, minute) -> {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        calendar.set(Calendar.MINUTE, minute);
                        calendar.set(Calendar.SECOND, 0);
                        calendar.set(Calendar.MILLISECOND, 0);

                        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
                            calendar.add(Calendar.DAY_OF_MONTH, 1);
                        }

                        long newTimeInMillis = calendar.getTimeInMillis();

                        cancelAlarm(alarm);

                        alarm.hour = hourOfDay;
                        alarm.minute = minute;
                        alarm.timeInMillis = newTimeInMillis;

                        new Thread(() -> {
                            try {
                                db.alarmDao().update(alarm);
                                runOnUiThread(() -> {
                                    setAlarmManager(newTimeInMillis, (int) alarm.id);
                                    loadAlarms();
                                    Toast.makeText(MainActivity.this, "Alarm updated", Toast.LENGTH_SHORT).show();
                                });
                            } catch (Exception e) {
                                Log.e(TAG, "Error updating alarm", e);
                            }
                        }).start();
                    },
                    alarm.hour,
                    alarm.minute,
                    true
            );

            timePickerDialog.show();
        }

        @Override
        protected void onDestroy() {
            super.onDestroy();
            if (bluetoothSocket != null) {
                try {
                    bluetoothSocket.close();
                } catch (IOException e) {
                    Log.e(TAG, "Could not close the Bluetooth socket", e);
                }
            }
        }

        @Override
        public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            if (requestCode == REQUEST_PERMISSION_BLUETOOTH) {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    connectBluetooth();
                } else {
                    Toast.makeText(this, "Bluetooth permission is required to connect", Toast.LENGTH_SHORT).show();
                }
            }
        }

        private void startVoiceAssistantService() {
            Intent serviceIntent = new Intent(this, VoiceAssistantService.class);
            startService(serviceIntent);
        }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == REQUEST_ENABLE_BT) {
                if (resultCode == RESULT_OK) {
                    connectToHC05();
                } else {
                    Toast.makeText(this, "Bluetooth is required for this app", Toast.LENGTH_SHORT).show();
                }
            }
        }

        private BroadcastReceiver updateAlarmsReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                loadAlarms();
            }
        };

        @Override
        protected void onResume() {
            super.onResume();
            registerReceiver(updateAlarmsReceiver, new IntentFilter("UPDATE_ALARMS"));
        }

        @Override
        protected void onPause() {
            super.onPause();
            unregisterReceiver(updateAlarmsReceiver);
        }

        // Static methods to access bluetoothSocket and outputStream
        public static BluetoothSocket getBluetoothSocket() {
            return bluetoothSocket;
        }

        public static OutputStream getOutputStream() {
            return outputStream;
        }
    }
