package com.example.todocare;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class MailActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mail);  // Make sure you have this layout file

        // Initialize ImageViews
        ImageView ivTime = findViewById(R.id.ivTime);
        ImageView ivMail = findViewById(R.id.ivMail);

        // Set onClickListener for ivTime
        ivTime.setOnClickListener(v -> {
            Intent timeIntent = new Intent(MailActivity.this, MainActivity.class);
            startActivity(timeIntent);
            finish();  // Close this activity when moving back to MainActivity
        });

        // Set onClickListener for ivMail (optional, as we're already in MailActivity)
        ivMail.setOnClickListener(v -> {
            // You can add some action here if needed, or leave it empty
        });
    }
}