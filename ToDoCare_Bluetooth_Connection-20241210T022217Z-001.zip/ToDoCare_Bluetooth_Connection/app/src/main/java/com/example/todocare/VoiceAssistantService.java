package com.example.todocare;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;
import android.widget.Toast;

import androidx.room.Room;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceAssistantService extends Service implements RecognitionListener {

    private static final String TAG = "VoiceAssistantService";
    private static final String KEYPHRASE = "hey alarm";
    private static final String TIME_COMMAND_PATTERN = "(set an alarm for|wake me up at|set alarm at|set alarm for|set alarm to) (\\d{1,2}:?\\d{0,2}\\s*(AM|PM|am|pm)?)"; // Adjusted to accept time without a mandatory minute

    private SpeechRecognizer speechRecognizer;
    private boolean isListeningForTime;

    // Store alarms in a Map with their IDs and trigger times
    private Map<Integer, Long> alarms = new HashMap<>();
    private int alarmIdCounter = 0; // Unique ID for each alarm
    private static final int MAX_ALARMS = 4; // Maximum number of alarms

    private boolean isInCooldown = false; // Flag to track cooldown state
    private static final long COOLDOWN_DELAY = 5000; // 3 seconds delay in milliseconds
    private Handler cooldownHandler = new Handler(Looper.getMainLooper()); // Handler for managing cooldown


    private AlarmDatabase db;

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            db = Room.databaseBuilder(getApplicationContext(), AlarmDatabase.class, "alarm-database").build();
            Log.d(TAG, "Database initialized successfully.");
        } catch (Exception e) {
            Log.e(TAG, "Database initialization failed: " + e.getMessage());
        }

        initializeSpeechRecognizer();
        Log.d(TAG, "VoiceAssistantService created");
        Toast.makeText(this, "Voice Assistant Service Started", Toast.LENGTH_SHORT).show();
        isListeningForTime = false;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startListening();
        Log.d(TAG, "VoiceAssistantService started listening");
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
            Log.d(TAG, "Speech recognizer destroyed");
        }
        Log.d(TAG, "VoiceAssistantService destroyed");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void initializeSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(this);
            Log.d(TAG, "Speech recognizer initialized");
        } else {
            Log.e(TAG, "Speech recognition is not available on this device");
            Toast.makeText(this, "Speech recognition not available", Toast.LENGTH_LONG).show();
        }
    }

    private void startListening() {
        if (speechRecognizer != null) {
            Intent recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            speechRecognizer.startListening(recognizerIntent);
            Log.d(TAG, "Started listening for speech");
        }
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        Log.d(TAG, "Ready for speech");
    }

    @Override
    public void onBeginningOfSpeech() {
        Log.d(TAG, "Speech started");
    }

    @Override
    public void onRmsChanged(float rmsdB) {
    }

    @Override
    public void onBufferReceived(byte[] buffer) {
        Log.d(TAG, "Buffer received");
    }

    @Override
    public void onEndOfSpeech() {
        Log.d(TAG, "Speech ended");
    }

    @Override
    public void onError(int error) {
        String errorMessage = "Unknown error";
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO:
                errorMessage = "Audio recording error";
                break;
            case SpeechRecognizer.ERROR_CLIENT:
                errorMessage = "Client side error";
                break;
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                errorMessage = "Insufficient permissions";
                break;
            case SpeechRecognizer.ERROR_NETWORK:
                errorMessage = "Network error";
                break;
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                errorMessage = "Network timeout";
                break;
            case SpeechRecognizer.ERROR_NO_MATCH:
                errorMessage = "No match";
                break;
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                errorMessage = "Recognition service busy";
                break;
            case SpeechRecognizer.ERROR_SERVER:
                errorMessage = "Error from server";
                break;
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                errorMessage = "No speech input";
                break;
        }
        Log.e(TAG, "Speech recognition error: " + errorMessage);
        Toast.makeText(this, "Speech Error: " + errorMessage, Toast.LENGTH_SHORT).show();
        speechRecognizer.cancel();
        startListening();
    }

    @Override
    public void onResults(Bundle results) {
        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null) {
            for (String result : matches) {
                Log.d(TAG, "Speech result: " + result);
                if (!isListeningForTime) {
                    // Listen for the keyphrase to start alarm setup
                    if (result.toLowerCase().contains(KEYPHRASE) && !isInCooldown) {
                        Log.d(TAG, "Wake word detected");
                        Toast.makeText(this, "Wake word detected: " + KEYPHRASE, Toast.LENGTH_LONG).show();
                        isListeningForTime = true;
                        Toast.makeText(this, "Please state the time to set the alarm.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Listen for the time to set the alarm
                    if (checkTimeCommand(result) && !isInCooldown) {
                        isInCooldown = true; // Set the cooldown flag
                        String time = extractTime(result);
                        if (time != null) {
                            Log.d(TAG, "Setting alarm for: " + time);
                            Toast.makeText(this, "Setting alarm for: " + time, Toast.LENGTH_LONG).show();
                            setAlarm(time);  // Set the alarm

                            // Start cooldown timer
                            cooldownHandler.postDelayed(() -> {
                                isInCooldown = false; // Reset cooldown flag after delay
                                isListeningForTime = false; // Reset listening state to allow new commands
                            }, COOLDOWN_DELAY);
                        } else {
                            Log.d(TAG, "Time extraction failed");
                        }
                    }
                }
            }
        }
        // Restart listening for keyphrase only if not in cooldown state
        if (!isInCooldown) {
            startListening();
        }
    }
    private boolean isDuplicateAlarm(String time) {
        String[] timeParts = time.split(":|\\s+");
        int hour = Integer.parseInt(timeParts[0]);
        int minute = (timeParts.length > 1) ? Integer.parseInt(timeParts[1]) : 0;

        for (Map.Entry<Integer, Long> entry : alarms.entrySet()) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(entry.getValue());
            if (calendar.get(Calendar.HOUR_OF_DAY) == hour && calendar.get(Calendar.MINUTE) == minute) {
                return true; // Duplicate alarm found
            }
        }
        return false; // No duplicate found
    }


    @Override
    public void onPartialResults(Bundle partialResults) {
        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches != null) {
            for (String result : matches) {
                Log.d(TAG, "Partial speech result: " + result);
                if (!isListeningForTime) {
                    if (result.toLowerCase().contains(KEYPHRASE)) {
                        Log.d(TAG, "Wake word detected");
                        Toast.makeText(this, "Wake word detected: " + KEYPHRASE, Toast.LENGTH_LONG).show();
                        isListeningForTime = true;
                        Toast.makeText(this, "Please state the time to set the alarm.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    if (checkTimeCommand(result)) {
                        String time = extractTime(result);
                        if (time != null) {
                            Log.d(TAG, "Setting alarm for: " + time);
                            Toast.makeText(this, "Setting alarm for: " + time, Toast.LENGTH_LONG).show();
                            setAlarm(time);
                        } else {
                            Log.d(TAG, "Time extraction failed");
                        }
                        isListeningForTime = false;
                    }
                }
            }
        }
    }

    @Override
    public void onEvent(int eventType, Bundle params) {
        Log.d(TAG, "Speech event: " + eventType);
    }

    private boolean checkTimeCommand(String result) {
        Pattern pattern = Pattern.compile(TIME_COMMAND_PATTERN, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(result);
        return matcher.find();
    }

    private String extractTime(String result) {
        Pattern pattern = Pattern.compile(TIME_COMMAND_PATTERN, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(result);
        if (matcher.find()) {
            return matcher.group(2);
        }
        return null;
    }

    @SuppressLint("ScheduleExactAlarm")
    private void setAlarm(String time) {
        if (db == null) {
            Log.e(TAG, "Database is not initialized");
            return;
        }

        String[] timeParts = time.split(":|\\s+");
        int hour = Integer.parseInt(timeParts[0]);
        int minute = (timeParts.length > 1) ? Integer.parseInt(timeParts[1]) : 0;
        String amPm = (timeParts.length > 2) ? timeParts[2].toUpperCase() : ""; // Get AM/PM

        // Convert to 24-hour format
        if (amPm.equals("PM") && hour < 12) {
            hour += 12; // Convert PM hour
        } else if (amPm.equals("AM") && hour == 12) {
            hour = 0; // Convert 12 AM to 0 hours
        }

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        if (calendar.before(Calendar.getInstance())) {
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        long alarmTimeInMillis = calendar.getTimeInMillis();

        // Rest of the code remains the same...
        int finalHour = calendar.get(Calendar.HOUR);
        String finalAmPm = calendar.get(Calendar.AM_PM) == Calendar.AM ? "AM" : "PM";

        new Thread(() -> {
            try {
                Alarm alarm = new Alarm();
                alarm.hour = finalHour;
                alarm.minute = minute;
                alarm.timeInMillis = alarmTimeInMillis;
                long alarmId = db.alarmDao().insert(alarm);

                if (alarmId != -1) {
                    Log.d(TAG, "Alarm inserted with ID: " + alarmId);
                    setAlarmManager(alarmTimeInMillis, (int) alarmId);
                    String message = "Alarm set for " + String.format("%02d:%02d %s", finalHour, minute, finalAmPm);
                    Log.d(TAG, message);
                    new Handler(Looper.getMainLooper()).post(() ->
                            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show()
                    );

                    Intent intent = new Intent("UPDATE_ALARMS");
                    sendBroadcast(intent);
                } else {
                    Log.e(TAG, "Failed to insert alarm");
                    new Handler(Looper.getMainLooper()).post(() ->
                            Toast.makeText(getApplicationContext(), "Failed to set alarm", Toast.LENGTH_SHORT).show()
                    );
                }
            } catch (Exception e) {
                Log.e(TAG, "Error setting alarm", e);
                new Handler(Looper.getMainLooper()).post(() ->
                        Toast.makeText(getApplicationContext(), "Error setting alarm", Toast.LENGTH_SHORT).show()
                );
            }
        }).start();
    }

    @SuppressLint("ScheduleExactAlarm")
    private void setAlarmManager(long timeInMillis, int requestCode) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("requestCode", requestCode);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AlarmManager.AlarmClockInfo alarmClockInfo = new AlarmManager.AlarmClockInfo(timeInMillis, pendingIntent);
            alarmManager.setAlarmClock(alarmClockInfo, pendingIntent);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, timeInMillis, pendingIntent);
        }

        Log.d(TAG, "Alarm set for " + new java.util.Date(timeInMillis).toString() + " with request code: " + requestCode);
    }
}
