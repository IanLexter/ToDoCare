package com.example.todocare;

import android.annotation.SuppressLint;
import android.app.IntentService;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class BluetoothCommandService extends IntentService {
    private static final String TAG = "BluetoothCommandService";
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothDevice hc05Device;
    private BluetoothSocket bluetoothSocket;
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private static final String HC_05_NAME = "HC-05";

    public BluetoothCommandService() {
        super("BluetoothCommandService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            char command = intent.getCharExtra("command", '0');
            sendBluetoothCommand(command);
        }
    }

    @SuppressLint("MissingPermission")
    private void sendBluetoothCommand(char command) {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Log.e(TAG, "Device doesn't support Bluetooth");
            return;
        }

        Set<BluetoothDevice> pairedDevices = bluetoothAdapter.getBondedDevices();
        for (BluetoothDevice device : pairedDevices) {
            if (device.getName().equals(HC_05_NAME)) {
                hc05Device = device;
                break;
            }
        }

        if (hc05Device == null) {
            Log.e(TAG, "HC-05 not found");
            return;
        }

        try {
            bluetoothSocket = hc05Device.createRfcommSocketToServiceRecord(MY_UUID);
            bluetoothSocket.connect();
            OutputStream outputStream = bluetoothSocket.getOutputStream();
            outputStream.write(command);
            Log.d(TAG, "Bluetooth command sent: " + command);
            bluetoothSocket.close();
        } catch (IOException e) {
            Log.e(TAG, "Error sending Bluetooth command", e);
        }
    }
}
